#!/usr/bin/env bash

sudo cp -fv "mosh"* "/usr/local/bin"
sudo cp -fv "lib"* "/usr/lib/x86_64-linux-gnu/"
